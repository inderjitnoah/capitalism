import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-WOEwx942.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MIN_PLAYERS = 2;
var MAX_PLAYERS = 6;
var CLASS_NAMES = {
	low: "Proletariat",
	mid: "Middle Class",
	high: "Bourgeoisie"
};
function Pencil() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "16",
		height: "16",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 20h9" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" })]
	});
}
function Check() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "16",
		height: "16",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20 6 9 17l-5-5" })
	});
}
function Trash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "16",
		height: "16",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M3 6h18" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 6V4h8v2" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19 6l-1 14H6L5 6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 11v6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14 11v6" })
		]
	});
}
function initialSetup() {
	return [
		1,
		2,
		3,
		4
	].map((n) => ({
		id: n,
		name: `Player ${n}`,
		editing: false
	}));
}
function classFor(capital) {
	if (capital >= 15) return "high";
	if (capital >= 8) return "mid";
	return "low";
}
function Home() {
	const nextId = (0, import_react.useRef)(5);
	const logId = (0, import_react.useRef)(1);
	const [setup, setSetup] = (0, import_react.useState)(initialSetup);
	const [screen, setScreen] = (0, import_react.useState)("setup");
	const [showRules, setShowRules] = (0, import_react.useState)(false);
	const [players, setPlayers] = (0, import_react.useState)([]);
	const [current, setCurrent] = (0, import_react.useState)(0);
	const [turn, setTurn] = (0, import_react.useState)(1);
	const [wageBonus, setWageBonus] = (0, import_react.useState)(0);
	const [logs, setLogs] = (0, import_react.useState)([]);
	const [modal, setModal] = (0, import_react.useState)(null);
	const [winner, setWinner] = (0, import_react.useState)("");
	const afterModal = (0, import_react.useRef)(null);
	function pushLog(text, who) {
		const id = logId.current++;
		setLogs((prev) => [{
			id,
			who,
			text
		}, ...prev]);
	}
	function openModal(title, text, num, neg = false, then) {
		afterModal.current = then ?? null;
		setModal({
			title,
			text,
			num,
			neg
		});
	}
	function finishAction(nextPlayers, won, bonus = wageBonus) {
		const mapped = nextPlayers.map((p) => ({
			...p,
			class: classFor(p.capital)
		}));
		setPlayers(mapped);
		setWageBonus(bonus);
		if (won && won.capital >= 20) {
			setTimeout(() => {
				setWinner(won.name);
				setScreen("win");
				setModal(null);
			}, 700);
			return;
		}
	}
	function advance(fromPlayers) {
		const count = fromPlayers.length;
		const nextIndex = (current + 1) % count;
		if (nextIndex === 0) {
			const nextTurn = turn + 1;
			setTurn(nextTurn);
			setCurrent(0);
			if (Math.random() < .4) {
				const events = [
					{
						title: "Economic Boom",
						text: "Demand is high. Everyone gains 1 capital.",
						apply: (list) => list.map((p) => ({
							...p,
							capital: p.capital + 1
						}))
					},
					{
						title: "Recession",
						text: "A recession hits. Everyone loses 1 capital.",
						apply: (list) => list.map((p) => ({
							...p,
							capital: Math.max(0, p.capital - 1)
						}))
					},
					{
						title: "New Regulation",
						text: "Workers gain protection. Wage bonus +1 (max 2).",
						apply: (list) => list,
						bonus: Math.min(2, wageBonus + 1)
					},
					{
						title: "Automation",
						text: "Tech disrupts labor. Players with under 5 capital lose 1.",
						apply: (list) => list.map((p) => p.capital < 5 ? {
							...p,
							capital: Math.max(0, p.capital - 1)
						} : p)
					},
					{
						title: "Union Strength",
						text: "Solidarity grows. The next successful strike will be stronger.",
						apply: (list) => list
					}
				];
				const ev = events[Math.floor(Math.random() * events.length)];
				const applied = ev.apply(fromPlayers).map((p) => ({
					...p,
					class: classFor(p.capital)
				}));
				const bonus = "bonus" in ev && typeof ev.bonus === "number" ? ev.bonus : wageBonus;
				setPlayers(applied);
				setWageBonus(bonus);
				pushLog(ev.title);
				openModal(ev.title, ev.text, null);
				return;
			}
		} else setCurrent(nextIndex);
	}
	function closeModal() {
		const fn = afterModal.current;
		afterModal.current = null;
		setModal(null);
		if (fn) fn();
	}
	function act(type) {
		if (screen !== "game" || modal) return;
		const list = players.map((p) => ({ ...p }));
		const p = list[current];
		if (!p) return;
		const go = (title, text, num, neg, bonus = wageBonus) => {
			const won = p.capital >= 20 ? p : null;
			finishAction(list, won, bonus);
			if (!won) openModal(title, text, num, neg, () => advance(list));
			else openModal(title, text, num, neg);
		};
		if (type === "work") {
			let earn = Math.floor(Math.random() * 3) + 1 + wageBonus;
			if (Math.random() < .28) {
				earn = Math.max(0, earn - 1);
				p.capital += earn;
				pushLog(`faced exploitation. Gained only ${earn}.`, p.name);
				go("Exploitation", `${p.name} worked hard, but the owners of the means of production took the surplus value.`, earn, true);
			} else {
				p.capital += earn;
				pushLog(`worked and earned ${earn} capital.`, p.name);
				go("Labor", `${p.name} sold their labor and earned capital.`, earn, false);
			}
			return;
		}
		if (type === "invest") {
			if (p.capital < 2) return;
			p.capital -= 2;
			if (Math.random() < .58) {
				const ret = Math.floor(Math.random() * 3) + 4;
				p.capital += ret;
				pushLog(`invested 2 and gained ${ret}.`, p.name);
				go("Investment", `${p.name} invested in the means of production and reaped the returns.`, ret, false);
			} else {
				pushLog("invested and lost 2 capital.", p.name);
				go("Bad Investment", `${p.name}'s capital vanished into a failed venture.`, -2, true);
			}
			return;
		}
		if (type === "organize") {
			if (Math.random() < .62) {
				const bonus = Math.min(2, wageBonus + 1);
				pushLog(`organized a successful strike. Wage bonus +${bonus}.`, p.name);
				go("Solidarity", `The strike worked. Through collective action, all workers now earn +${bonus} extra when they Work.`, null, false, bonus);
			} else {
				p.capital = Math.max(0, p.capital - 1);
				pushLog("strike failed.", p.name);
				go("Strike Broken", `The owners crushed the strike. ${p.name} lost 1 capital.`, -1, true);
			}
			return;
		}
		const roll = Math.random();
		if (roll < .32) {
			const gain = Math.floor(Math.random() * 5) + 4;
			p.capital += gain;
			pushLog(`speculated and gained ${gain}!`, p.name);
			go("Market Boom", `${p.name} gambled and hit it big.`, gain, false);
		} else if (roll < .62) {
			const gain = Math.floor(Math.random() * 2) + 1;
			p.capital += gain;
			pushLog(`speculated and gained ${gain}.`, p.name);
			go("Small Gain", `${p.name} made a modest profit.`, gain, false);
		} else {
			p.capital = Math.max(0, p.capital - 2);
			pushLog("speculated and lost 2.", p.name);
			go("Market Crash", `${p.name} lost capital in a risky speculative bet.`, -2, true);
		}
	}
	function addPlayer() {
		if (setup.length >= MAX_PLAYERS) return;
		const id = nextId.current++;
		setSetup((prev) => [...prev.map((p) => ({
			...p,
			editing: false,
			name: p.name.trim() || "Player"
		})), {
			id,
			name: `Player ${prev.length + 1}`,
			editing: true
		}]);
	}
	function removePlayer(id) {
		setSetup((prev) => prev.length <= MIN_PLAYERS ? prev : prev.filter((p) => p.id !== id));
	}
	function toggleEdit(id) {
		setSetup((prev) => {
			const target = prev.find((p) => p.id === id);
			const opening = target ? !target.editing : false;
			return prev.map((p) => {
				const name = p.name.trim() || "Player";
				if (p.id === id) return {
					...p,
					name,
					editing: opening
				};
				return {
					...p,
					name,
					editing: false
				};
			});
		});
	}
	function startGame() {
		const named = setup.map((p, i) => ({
			name: p.name.trim() || `Player ${i + 1}`,
			capital: 1,
			class: "low"
		}));
		if (named.length < MIN_PLAYERS) return;
		setPlayers(named);
		setCurrent(0);
		setTurn(1);
		setWageBonus(0);
		setWinner("");
		setLogs([{
			id: logId.current++,
			text: "Game started. Everyone begins as the proletariat with 1 capital."
		}]);
		setScreen("game");
	}
	function reset() {
		setScreen("setup");
		setSetup(initialSetup());
		nextId.current = 5;
		setPlayers([]);
		setModal(null);
		setShowRules(false);
	}
	const active = players[current];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "app-header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "logo",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "Capitalism" }), " Takes Over"]
			}), screen === "game" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "header-meta",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Turn ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: turn })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: players.length }), " players"] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container",
			children: [
				screen === "setup" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "screen",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "setup-wrap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "setup-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "New Game" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "lead",
									children: "Start as the proletariat with almost nothing. Work, invest, organize, or speculate to reach the bourgeoisie. First to 20 capital wins."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "field-label",
									children: "Players"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "players-setup",
									children: setup.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "player-row",
										children: [
											p.editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												className: "name-input",
												value: p.name,
												maxLength: 24,
												autoFocus: true,
												"aria-label": "Player name",
												onChange: (e) => setSetup((prev) => prev.map((x) => x.id === p.id ? {
													...x,
													name: e.target.value
												} : x)),
												onKeyDown: (e) => {
													if (e.key === "Enter") toggleEdit(p.id);
												}
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "player-name-view",
												children: p.name.trim() || "Unnamed"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "icon-btn",
												title: p.editing ? "Done" : "Edit name",
												"aria-label": p.editing ? "Done editing name" : "Edit player name",
												onClick: () => toggleEdit(p.id),
												children: p.editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "icon-btn danger",
												title: "Remove player",
												"aria-label": "Remove player",
												disabled: setup.length <= MIN_PLAYERS,
												onClick: () => removePlayer(p.id),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash, {})
											})
										]
									}, p.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost add-player",
									disabled: setup.length >= MAX_PLAYERS,
									onClick: addPlayer,
									children: setup.length >= MAX_PLAYERS ? "Max 6 players" : "Add player"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "btn-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn btn-primary",
										onClick: startGame,
										children: "Start Game"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "btn btn-ghost",
										onClick: () => setShowRules((v) => !v),
										children: "Rules"
									})]
								}),
								showRules && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rules-box",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", { children: "How to Play" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Each turn choose one action." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Work" }), " — Steady capital, chance of exploitation."] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Invest" }), " — Risk capital for bigger returns."] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Organize" }), " — Collective action that helps everyone."] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Speculate" }), " — High risk, high reward."] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Market events can help or hurt the whole table." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "First to 20 capital joins the bourgeoisie and wins." })
									] })]
								})
							]
						})
					})
				}),
				screen === "game" && active && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "screen",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "game-top",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "turn-pill",
								children: ["Turn: ", active.name]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost",
								style: {
									fontSize: "0.78rem",
									padding: "0.35rem 0.7rem"
								},
								onClick: reset,
								children: "Quit"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "players-grid",
							children: players.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `player-card${i === current ? " active" : ""}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "player-name",
										children: p.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "player-class",
										children: CLASS_NAMES[p.class]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "stat-row",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "label",
											children: "Capital"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "value",
											children: [p.capital, " / 20"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "capital-bar",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "capital-fill",
											style: { width: `${Math.min(100, p.capital / 20 * 100)}%` }
										})
									})
								]
							}, p.name + i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "action-panel",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Choose an Action" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "action-desc",
									children: "Sell your labor or play the system."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "actions",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "action-btn",
											onClick: () => act("work"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "title",
												children: "Work"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "sub",
												children: "Earn 1–3 capital. Risk of exploitation."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "action-btn",
											disabled: active.capital < 2,
											onClick: () => act("invest"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "title",
												children: "Invest"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "sub",
												children: "Spend 2. Chance of 4–6 return."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "action-btn",
											onClick: () => act("organize"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "title",
												children: "Organize"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "sub",
												children: "Strike! Raises wages for all."
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											className: "action-btn",
											onClick: () => act("speculate"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "title",
												children: "Speculate"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "sub",
												children: "High risk: big gain or lose 2."
											})]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "log-panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Game Log" }), logs.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "log-entry",
								children: [line.who ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "who",
									children: [line.who, " "]
								}) : null, line.text]
							}, line.id))]
						})
					]
				}),
				screen === "win" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "screen win-screen",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { children: [winner, " Wins"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "subtitle",
							children: [winner, " reached 20 capital and joined the bourgeoisie."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							style: {
								maxWidth: 400,
								margin: "0 auto 1.8rem",
								color: "var(--text-2)",
								fontSize: "0.94rem"
							},
							children: "You now control the means of production."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-primary",
							onClick: reset,
							children: "Play Again"
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
			className: "app-footer",
			children: "10th Grade Global History • Designing Economics Games"
		}),
		modal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "modal-overlay",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "modal",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: modal.title }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: modal.text }),
					modal.num !== null && modal.num !== 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `big-num${modal.neg || modal.num < 0 ? " neg" : ""}`,
						children: [modal.num > 0 ? "+" : "", modal.num]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-primary",
						onClick: closeModal,
						children: "Continue"
					})
				]
			})
		})
	] });
}
//#endregion
export { Home as component };
