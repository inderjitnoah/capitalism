//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHad_GxV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CTDwhtUU.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CTDwhtUU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-4FLOIYOJ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
