import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";

export const Route = createFileRoute("/")({ component: Home });

const MIN_PLAYERS = 2;
const MAX_PLAYERS = 6;

type ClassName = "low" | "mid" | "high";
type Screen = "setup" | "game" | "win";

type SetupPlayer = { id: number; name: string; editing: boolean };
type Player = { name: string; capital: number; class: ClassName };
type LogLine = { id: number; who?: string; text: string };
type ModalState = { title: string; text: string; num: number | null; neg: boolean } | null;

const CLASS_NAMES: Record<ClassName, string> = {
  low: "Proletariat",
  mid: "Middle Class",
  high: "Bourgeoisie",
};

function Pencil() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z" />
    </svg>
  );
}

function Check() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}

function Trash() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M3 6h18" />
      <path d="M8 6V4h8v2" />
      <path d="M19 6l-1 14H6L5 6" />
      <path d="M10 11v6" />
      <path d="M14 11v6" />
    </svg>
  );
}

function initialSetup(): SetupPlayer[] {
  return [1, 2, 3, 4].map((n) => ({ id: n, name: `Player ${n}`, editing: false }));
}

function classFor(capital: number): ClassName {
  if (capital >= 15) return "high";
  if (capital >= 8) return "mid";
  return "low";
}

function Home() {
  const nextId = useRef(5);
  const logId = useRef(1);
  const [setup, setSetup] = useState<SetupPlayer[]>(initialSetup);
  const [screen, setScreen] = useState<Screen>("setup");
  const [showRules, setShowRules] = useState(false);
  const [players, setPlayers] = useState<Player[]>([]);
  const [current, setCurrent] = useState(0);
  const [turn, setTurn] = useState(1);
  const [wageBonus, setWageBonus] = useState(0);
  const [logs, setLogs] = useState<LogLine[]>([]);
  const [modal, setModal] = useState<ModalState>(null);
  const [winner, setWinner] = useState("");
  const afterModal = useRef<(() => void) | null>(null);

  function pushLog(text: string, who?: string) {
    const id = logId.current++;
    setLogs((prev) => [{ id, who, text }, ...prev]);
  }

  function openModal(title: string, text: string, num: number | null, neg = false, then?: () => void) {
    afterModal.current = then ?? null;
    setModal({ title, text, num, neg });
  }

  function finishAction(nextPlayers: Player[], won: Player | null, bonus = wageBonus) {
    const mapped = nextPlayers.map((p) => ({ ...p, class: classFor(p.capital) }));
    setPlayers(mapped);
    setWageBonus(bonus);
    if (won && won.capital >= 20) {
      setTimeout(() => {
        setWinner(won.name);
        setScreen("win");
        setModal(null);
      }, 700);
      return;
    }
  }

  function advance(fromPlayers: Player[]) {
    const count = fromPlayers.length;
    const nextIndex = (current + 1) % count;
    if (nextIndex === 0) {
      const nextTurn = turn + 1;
      setTurn(nextTurn);
      setCurrent(0);
      if (Math.random() < 0.4) {
        const events = [
          {
            title: "Economic Boom",
            text: "Demand is high. Everyone gains 1 capital.",
            apply: (list: Player[]) => list.map((p) => ({ ...p, capital: p.capital + 1 })),
          },
          {
            title: "Recession",
            text: "A recession hits. Everyone loses 1 capital.",
            apply: (list: Player[]) => list.map((p) => ({ ...p, capital: Math.max(0, p.capital - 1) })),
          },
          {
            title: "New Regulation",
            text: "Workers gain protection. Wage bonus +1 (max 2).",
            apply: (list: Player[]) => list,
            bonus: Math.min(2, wageBonus + 1),
          },
          {
            title: "Automation",
            text: "Tech disrupts labor. Players with under 5 capital lose 1.",
            apply: (list: Player[]) =>
              list.map((p) => (p.capital < 5 ? { ...p, capital: Math.max(0, p.capital - 1) } : p)),
          },
          {
            title: "Windfall",
            text: "The player with the least capital finds 2 capital.",
            apply: (list: Player[]) => {
              const low = Math.min(...list.map((p) => p.capital));
              let given = false;
              return list.map((p) => {
                if (!given && p.capital === low) {
                  given = true;
                  return { ...p, capital: p.capital + 2 };
                }
                return p;
              });
            },
          },
          {
            title: "Luxury Tax",
            text: "The richest player pays 2 capital.",
            apply: (list: Player[]) => {
              const high = Math.max(...list.map((p) => p.capital));
              let taken = false;
              return list.map((p) => {
                if (!taken && p.capital === high && high > 0) {
                  taken = true;
                  return { ...p, capital: Math.max(0, p.capital - 2) };
                }
                return p;
              });
            },
          },
        ];
        const ev = events[Math.floor(Math.random() * events.length)]!;
        const applied = ev.apply(fromPlayers).map((p) => ({ ...p, class: classFor(p.capital) }));
        const bonus = "bonus" in ev && typeof ev.bonus === "number" ? ev.bonus : wageBonus;
        setPlayers(applied);
        setWageBonus(bonus);
        pushLog(ev.title);
        openModal(ev.title, ev.text, null);
        return;
      }
    } else {
      setCurrent(nextIndex);
    }
  }

  function closeModal() {
    const fn = afterModal.current;
    afterModal.current = null;
    setModal(null);
    if (fn) fn();
  }

  function act(type: "work" | "invest" | "organize" | "speculate" | "hustle" | "redistribute") {
    if (screen !== "game" || modal) return;
    const list = players.map((p) => ({ ...p }));
    const p = list[current];
    if (!p) return;

    const go = (title: string, text: string, num: number | null, neg: boolean, bonus = wageBonus) => {
      const won = p.capital >= 20 ? p : null;
      finishAction(list, won, bonus);
      if (!won) {
        openModal(title, text, num, neg, () => advance(list));
      } else {
        openModal(title, text, num, neg);
      }
    };

    if (type === "work") {
      let earn = Math.floor(Math.random() * 3) + 1 + wageBonus;
      if (Math.random() < 0.28) {
        earn = Math.max(0, earn - 1);
        p.capital += earn;
        pushLog(`faced exploitation. Gained only ${earn}.`, p.name);
        go("Exploitation", `${p.name} worked hard, but the owners of the means of production took the surplus value.`, earn, true);
      } else {
        p.capital += earn;
        pushLog(`worked and earned ${earn} capital.`, p.name);
        go("Labor", `${p.name} sold their labor and earned capital.`, earn, false);
      }
      return;
    }

    if (type === "invest") {
      if (p.capital < 2) return;
      p.capital -= 2;
      if (Math.random() < 0.58) {
        const ret = Math.floor(Math.random() * 3) + 4;
        p.capital += ret;
        pushLog(`invested 2 and gained ${ret}.`, p.name);
        go("Investment", `${p.name} invested in the means of production and reaped the returns.`, ret, false);
      } else {
        pushLog("invested and lost 2 capital.", p.name);
        go("Bad Investment", `${p.name}'s capital vanished into a failed venture.`, -2, true);
      }
      return;
    }

    if (type === "organize") {
      if (Math.random() < 0.62) {
        const bonus = Math.min(2, wageBonus + 1);
        pushLog(`organized a successful strike. Wage bonus +${bonus}.`, p.name);
        go("Solidarity", `The strike worked. Through collective action, all workers now earn +${bonus} extra when they Work.`, null, false, bonus);
      } else {
        p.capital = Math.max(0, p.capital - 1);
        pushLog("strike failed.", p.name);
        go("Strike Broken", `The owners crushed the strike. ${p.name} lost 1 capital.`, -1, true);
      }
      return;
    }

    const roll = Math.random();
    if (type === "hustle") {
      if (roll < 0.22) {
        p.capital += 5;
        pushLog("landed a huge side gig. +5!", p.name);
        go("Big Gig", `${p.name} caught a lucky gig-economy shift and banked 5 capital.`, 5, false);
      } else if (roll < 0.7) {
        p.capital += 2;
        pushLog("hustled for 2 capital.", p.name);
        go("Side Hustle", `${p.name} picked up extra work and earned 2 capital.`, 2, false);
      } else {
        pushLog("the gig was cancelled.", p.name);
        go("Gig Cancelled", `${p.name} waited around and got paid nothing.`, 0, true);
      }
      return;
    }

    if (type === "redistribute") {
      const richest = list.reduce((a, b) => (b.capital > a.capital ? b : a));
      if (richest === p || richest.capital < 2) {
        pushLog("found nobody richer to challenge.", p.name);
        go("No Target", `${p.name} is already on top. Nobody to take from.`, 0, false);
        return;
      }
      if (roll < 0.55) {
        const take = Math.min(2, richest.capital);
        richest.capital -= take;
        p.capital += take;
        pushLog(`took ${take} from ${richest.name}.`, p.name);
        go("Redistributed", `Collective pressure moved ${take} capital from ${richest.name} to ${p.name}.`, take, false);
      } else {
        p.capital = Math.max(0, p.capital - 1);
        pushLog("got pushed back and lost 1.", p.name);
        go("Pushed Back", `The owners shut it down. ${p.name} lost 1 capital.`, -1, true);
      }
      return;
    }

    if (roll < 0.28) {
      const gain = Math.floor(Math.random() * 5) + 4;
      p.capital += gain;
      pushLog(`speculated and gained ${gain}!`, p.name);
      go("Market Boom", `${p.name} gambled and hit it big.`, gain, false);
    } else if (roll < 0.62) {
      const gain = Math.floor(Math.random() * 2) + 1;
      p.capital += gain;
      pushLog(`speculated and gained ${gain}.`, p.name);
      go("Small Gain", `${p.name} made a modest profit.`, gain, false);
    } else {
      p.capital = Math.max(0, p.capital - 2);
      pushLog("speculated and lost 2.", p.name);
      go("Market Crash", `${p.name} lost capital in a risky speculative bet.`, -2, true);
    }
  }

  function addPlayer() {
    if (setup.length >= MAX_PLAYERS) return;
    const id = nextId.current++;
    setSetup((prev) => [
      ...prev.map((p) => ({ ...p, editing: false, name: p.name.trim() || "Player" })),
      { id, name: `Player ${prev.length + 1}`, editing: true },
    ]);
  }

  function removePlayer(id: number) {
    setSetup((prev) => (prev.length <= MIN_PLAYERS ? prev : prev.filter((p) => p.id !== id)));
  }

  function toggleEdit(id: number) {
    setSetup((prev) => {
      const target = prev.find((p) => p.id === id);
      const opening = target ? !target.editing : false;
      return prev.map((p) => {
        const name = p.name.trim() || "Player";
        if (p.id === id) return { ...p, name, editing: opening };
        return { ...p, name, editing: false };
      });
    });
  }

  function startGame() {
    const named = setup.map((p, i) => ({
      name: p.name.trim() || `Player ${i + 1}`,
      capital: 1,
      class: "low" as ClassName,
    }));
    if (named.length < MIN_PLAYERS) return;
    setPlayers(named);
    setCurrent(0);
    setTurn(1);
    setWageBonus(0);
    setWinner("");
    setLogs([{ id: logId.current++, text: "Game started. Everyone begins as the proletariat with 1 capital." }]);
    setScreen("game");
  }

  function reset() {
    setScreen("setup");
    setSetup(initialSetup());
    nextId.current = 5;
    setPlayers([]);
    setModal(null);
    setShowRules(false);
  }

  const active = players[current];

  return (
    <>
      <header className="app-header">
        <div className="logo">
          <em>Capitalism</em> Takes Over
        </div>
        {screen === "game" && (
          <div className="header-meta">
            <div>
              Turn <strong>{turn}</strong>
            </div>
            <div>
              <strong>{players.length}</strong> players
            </div>
          </div>
        )}
      </header>

      <div className="container">
        {screen === "setup" && (
          <div className="screen">
            <div className="setup-wrap">
              <div className="setup-card">
                <h2>New Game</h2>
                <p className="lead">First to 20 capital wins.</p>
                <span className="field-label">Players</span>
                <div className="players-setup">
                  {setup.map((p) => (
                    <div className="player-row" key={p.id}>
                      {p.editing ? (
                        <input
                          className="name-input"
                          value={p.name}
                          maxLength={24}
                          autoFocus
                          aria-label="Player name"
                          onChange={(e) =>
                            setSetup((prev) => prev.map((x) => (x.id === p.id ? { ...x, name: e.target.value } : x)))
                          }
                          onKeyDown={(e) => {
                            if (e.key === "Enter") toggleEdit(p.id);
                          }}
                        />
                      ) : (
                        <div className="player-name-view">{p.name.trim() || "Unnamed"}</div>
                      )}
                      <button
                        type="button"
                        className="icon-btn"
                        title={p.editing ? "Done" : "Edit name"}
                        aria-label={p.editing ? "Done editing name" : "Edit player name"}
                        onClick={() => toggleEdit(p.id)}
                      >
                        {p.editing ? <Check /> : <Pencil />}
                      </button>
                      <button
                        type="button"
                        className="icon-btn danger"
                        title="Remove player"
                        aria-label="Remove player"
                        disabled={setup.length <= MIN_PLAYERS}
                        onClick={() => removePlayer(p.id)}
                      >
                        <Trash />
                      </button>
                    </div>
                  ))}
                </div>
                <button type="button" className="btn btn-ghost add-player" disabled={setup.length >= MAX_PLAYERS} onClick={addPlayer}>
                  {setup.length >= MAX_PLAYERS ? "Max 6 players" : "Add player"}
                </button>
                <div className="btn-row">
                  <button type="button" className="btn btn-primary" onClick={startGame}>
                    Start Game
                  </button>
                  <button type="button" className="btn btn-ghost" onClick={() => setShowRules((v) => !v)}>
                    Rules
                  </button>
                </div>
                {showRules && (
                  <div className="rules-box">
                    <h4>How to Play</h4>
                    <ul>
                      <li>Each turn choose one action.</li>
                      <li>
                        <strong>Work</strong> — Steady capital, chance of exploitation.
                      </li>
                      <li>
                        <strong>Invest</strong> — Risk capital for bigger returns.
                      </li>
                      <li>
                        <strong>Organize</strong> — Collective action that helps everyone.
                      </li>
                      <li>
                        <strong>Speculate</strong> — High risk, high reward.
                      </li>
                      <li>Market events can help or hurt the whole table.</li>
                      <li>First to 20 capital joins the bourgeoisie and wins.</li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {screen === "game" && active && (
          <div className="screen">
            <div className="game-top">
              <div className="turn-pill">Turn: {active.name}</div>
              <button type="button" className="btn btn-ghost" style={{ fontSize: "0.78rem", padding: "0.35rem 0.7rem" }} onClick={reset}>
                Quit
              </button>
            </div>
            <div className="players-grid">
              {players.map((p, i) => (
                <div className={`player-card${i === current ? " active" : ""}`} key={p.name + i}>
                  <div className="player-name">{p.name}</div>
                  <div className="player-class">{CLASS_NAMES[p.class]}</div>
                  <div className="stat-row">
                    <span className="label">Capital</span>
                    <span className="value">{p.capital} / 20</span>
                  </div>
                  <div className="capital-bar">
                    <div className="capital-fill" style={{ width: `${Math.min(100, (p.capital / 20) * 100)}%` }} />
                  </div>
                </div>
              ))}
            </div>
            <div className="action-panel">
              <h3>Your turn</h3>
              <div className="actions">
                <button type="button" className="action-btn" onClick={() => act("work")}>
                  <div className="title">Work</div>
                  <div className="sub">+1 to +3</div>
                </button>
                <button type="button" className="action-btn" disabled={active.capital < 2} onClick={() => act("invest")}>
                  <div className="title">Invest</div>
                  <div className="sub">Spend 2</div>
                </button>
                <button type="button" className="action-btn" onClick={() => act("organize")}>
                  <div className="title">Organize</div>
                  <div className="sub">Raise wages</div>
                </button>
                <button type="button" className="action-btn" onClick={() => act("speculate")}>
                  <div className="title">Speculate</div>
                  <div className="sub">High risk</div>
                </button>
                <button type="button" className="action-btn" onClick={() => act("hustle")}>
                  <div className="title">Hustle</div>
                  <div className="sub">Side gig</div>
                </button>
                <button type="button" className="action-btn" onClick={() => act("redistribute")}>
                  <div className="title">Redistribute</div>
                  <div className="sub">Take from the lead</div>
                </button>
              </div>
            </div>
            <div className="log-panel">
              <h3>Game Log</h3>
              {logs.map((line) => (
                <div className="log-entry" key={line.id}>
                  {line.who ? <span className="who">{line.who} </span> : null}
                  {line.text}
                </div>
              ))}
            </div>
          </div>
        )}

        {screen === "win" && (
          <div className="screen win-screen">
            <h1>{winner} Wins</h1>
            <p className="subtitle">{winner} reached 20 capital.</p>
            <button type="button" className="btn btn-primary" onClick={reset}>
              Play Again
            </button>
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>{modal.title}</h2>
            <p>{modal.text}</p>
            {modal.num !== null && modal.num !== 0 && (
              <div className={`big-num${modal.neg || modal.num < 0 ? " neg" : ""}`}>
                {modal.num > 0 ? "+" : ""}
                {modal.num}
              </div>
            )}
            <button type="button" className="btn btn-primary" onClick={closeModal}>
              Continue
            </button>
          </div>
        </div>
      )}
    </>
  );
}
